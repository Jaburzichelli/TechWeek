<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../../config/helpers.php';

verificarAutenticacao();
verificarPerfil(['admin']);
$usuario = obterUsuario($pdo);

$acao = $_GET['acao'] ?? '';
$reserva_id = (int)($_GET['id'] ?? 0);

if ($acao === 'confirmar' && $reserva_id) {
    $stmt = $pdo->prepare('UPDATE reservas SET status = "confirmada" WHERE id = ?');
    $stmt->execute([$reserva_id]);
    registrarLog($pdo, $usuario['id'], 'CONFIRMAR_RESERVA', "Reserva #$reserva_id confirmada");
    header('Location: /admin/gerenciar-reservas.php?sucesso=1');
    exit;
}

if ($acao === 'rejeitar' && $reserva_id) {
    $stmt = $pdo->prepare('UPDATE reservas SET status = "rejeitada" WHERE id = ?');
    $stmt->execute([$reserva_id]);
    registrarLog($pdo, $usuario['id'], 'REJEITAR_RESERVA', "Reserva #$reserva_id rejeitada");
    header('Location: /admin/gerenciar-reservas.php?sucesso=1');
    exit;
}

if ($acao === 'cancelar' && $reserva_id) {
    $stmt = $pdo->prepare('UPDATE reservas SET status = "cancelada" WHERE id = ?');
    $stmt->execute([$reserva_id]);
    registrarLog($pdo, $usuario['id'], 'CANCELAR_RESERVA', "Reserva #$reserva_id cancelada");
    header('Location: /admin/gerenciar-reservas.php?sucesso=1');
    exit;
}

// Obter todas as reservas
$stmt = $pdo->prepare('
    SELECT r.*, l.nome as local_nome, u.nome as usuario_nome 
    FROM reservas r
    JOIN locais l ON r.local_id = l.id
    JOIN usuarios u ON r.usuario_id = u.id
    ORDER BY r.data_inicio DESC
');
$stmt->execute();
$reservas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Reservas - Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC - Admin</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?> (Admin)</span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <a href="/reservas.php" class="nav-item">Minhas Reservas</a>
                <hr>
                <h3>Administração</h3>
                <a href="/admin/gerenciar-reservas.php" class="nav-item active">Gerenciar Reservas</a>
                <a href="/admin/usuarios.php" class="nav-item">Usuários</a>
                <a href="/admin/locais.php" class="nav-item">Locais</a>
                <a href="/admin/relatorios.php" class="nav-item">Relatórios</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Gerenciar Reservas</h2>
            </div>

            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">Ação realizada com sucesso!</div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>Solicitante</th>
                            <th>Local</th>
                            <th>Data/Hora</th>
                            <th>Tipo</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservas as $reserva): ?>
                            <tr>
                                <td>#<?php echo $reserva['id']; ?></td>
                                <td><?php echo $reserva['titulo']; ?></td>
                                <td><?php echo $reserva['usuario_nome']; ?></td>
                                <td><?php echo $reserva['local_nome']; ?></td>
                                <td><?php echo formatarData($reserva['data_inicio']); ?></td>
                                <td><?php echo ucfirst($reserva['tipo']); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $reserva['status'] === 'confirmada' ? 'success' : 
                                             ($reserva['status'] === 'pendente' ? 'warning' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($reserva['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($reserva['status'] === 'pendente'): ?>
                                        <a href="?acao=confirmar&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-success">Confirmar</a>
                                        <a href="?acao=rejeitar&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-danger">Rejeitar</a>
                                    <?php else: ?>
                                        <a href="?acao=cancelar&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-warning">Cancelar</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
