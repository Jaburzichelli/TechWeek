<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../../config/helpers.php';

verificarAutenticacao();
verificarPerfil(['admin']);
$usuario = obterUsuario($pdo);

$erro = '';
$sucesso = '';

// Criar novo local
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $nome = sanitizar($_POST['nome'] ?? '');
    $descricao = sanitizar($_POST['descricao'] ?? '');
    $capacidade = (int)($_POST['capacidade'] ?? 0);
    
    if (empty($nome) || $capacidade <= 0) {
        $erro = 'Nome e capacidade são obrigatórios';
    } else {
        $stmt = $pdo->prepare('INSERT INTO locais (nome, descricao, capacidade) VALUES (?, ?, ?)');
        if ($stmt->execute([$nome, $descricao, $capacidade])) {
            $sucesso = 'Local criado com sucesso!';
            registrarLog($pdo, $usuario['id'], 'CRIAR_LOCAL', "Local $nome criado");
        } else {
            $erro = 'Erro ao criar local';
        }
    }
}

// Obter todos os locais
$stmt = $pdo->prepare('SELECT * FROM locais ORDER BY nome');
$stmt->execute();
$locais = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Locais - Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC - Admin</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?> (Admin)</span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <hr>
                <h3>Administração</h3>
                <a href="/admin/gerenciar-reservas.php" class="nav-item">Gerenciar Reservas</a>
                <a href="/admin/usuarios.php" class="nav-item">Usuários</a>
                <a href="/admin/locais.php" class="nav-item active">Locais</a>
                <a href="/admin/relatorios.php" class="nav-item">Relatórios</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Gerenciar Locais</h2>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-danger"><?php echo $erro; ?></div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
                <div class="alert alert-success"><?php echo $sucesso; ?></div>
            <?php endif; ?>

            <!-- Formulário de Novo Local -->
            <div class="section">
                <h3>Novo Local</h3>
                <form method="POST" class="form">
                    <input type="hidden" name="acao" value="criar">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nome">Nome do Local</label>
                            <input type="text" id="nome" name="nome" required>
                        </div>
                        <div class="form-group">
                            <label for="capacidade">Capacidade</label>
                            <input type="number" id="capacidade" name="capacidade" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Criar Local</button>
                </form>
            </div>

            <!-- Lista de Locais -->
            <div class="section">
                <h3>Locais Cadastrados</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Descrição</th>
                                <th>Capacidade</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($locais as $local): ?>
                                <tr>
                                    <td><?php echo $local['nome']; ?></td>
                                    <td><?php echo substr($local['descricao'], 0, 50); ?></td>
                                    <td><?php echo $local['capacidade']; ?> pessoas</td>
                                    <td>
                                        <span class="badge <?php echo $local['ativo'] ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo $local['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="/admin/editar-local.php?id=<?php echo $local['id']; ?>" class="btn btn-sm btn-info">Editar</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
