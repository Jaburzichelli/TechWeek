<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../../config/helpers.php';

verificarAutenticacao();
verificarPerfil(['admin']);
$usuario = obterUsuario($pdo);

// Estatísticas gerais
$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas');
$stmt->execute();
$total_reservas = $stmt->fetch()['total'];

$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE status = "confirmada"');
$stmt->execute();
$confirmadas = $stmt->fetch()['total'];

$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE status = "pendente"');
$stmt->execute();
$pendentes = $stmt->fetch()['total'];

$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE status = "cancelada"');
$stmt->execute();
$canceladas = $stmt->fetch()['total'];

// Reservas por local
$stmt = $pdo->prepare('
    SELECT l.nome, COUNT(r.id) as total 
    FROM locais l 
    LEFT JOIN reservas r ON l.id = r.local_id 
    GROUP BY l.id, l.nome
');
$stmt->execute();
$reservas_por_local = $stmt->fetchAll();

// Reservas por mês
$stmt = $pdo->prepare('
    SELECT MONTH(data_inicio) as mes, COUNT(*) as total 
    FROM reservas 
    WHERE YEAR(data_inicio) = YEAR(NOW())
    GROUP BY MONTH(data_inicio)
');
$stmt->execute();
$reservas_por_mes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC - Admin</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?> (Admin)</span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <hr>
                <h3>Administração</h3>
                <a href="/admin/gerenciar-reservas.php" class="nav-item">Gerenciar Reservas</a>
                <a href="/admin/usuarios.php" class="nav-item">Usuários</a>
                <a href="/admin/locais.php" class="nav-item">Locais</a>
                <a href="/admin/relatorios.php" class="nav-item active">Relatórios</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Relatórios e Estatísticas</h2>
            </div>

            <!-- Cards de Estatísticas -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-content">
                        <h3>Total de Reservas</h3>
                        <p class="stat-number"><?php echo $total_reservas; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✓</div>
                    <div class="stat-content">
                        <h3>Confirmadas</h3>
                        <p class="stat-number"><?php echo $confirmadas; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-content">
                        <h3>Pendentes</h3>
                        <p class="stat-number"><?php echo $pendentes; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✕</div>
                    <div class="stat-content">
                        <h3>Canceladas</h3>
                        <p class="stat-number"><?php echo $canceladas; ?></p>
                    </div>
                </div>
            </div>

            <!-- Gráficos -->
            <div class="section">
                <h3>Reservas por Local</h3>
                <canvas id="chartLocais"></canvas>
            </div>

            <div class="section">
                <h3>Reservas por Mês (Este Ano)</h3>
                <canvas id="chartMeses"></canvas>
            </div>

            <!-- Tabela de Reservas por Local -->
            <div class="section">
                <h3>Detalhes por Local</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Local</th>
                                <th>Total de Reservas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reservas_por_local as $local): ?>
                                <tr>
                                    <td><?php echo $local['nome']; ?></td>
                                    <td><?php echo $local['total']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Gráfico de Reservas por Local
        const ctxLocais = document.getElementById('chartLocais').getContext('2d');
        new Chart(ctxLocais, {
            type: 'doughnut',
            data: {
                labels: [<?php echo implode(',', array_map(fn($l) => '"' . $l['nome'] . '"', $reservas_por_local)); ?>],
                datasets: [{
                    data: [<?php echo implode(',', array_map(fn($l) => $l['total'], $reservas_por_local)); ?>],
                    backgroundColor: ['#2E7D32', '#1976D2', '#F57C00', '#C62828', '#6A1B9A']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Gráfico de Reservas por Mês
        const ctxMeses = document.getElementById('chartMeses').getContext('2d');
        new Chart(ctxMeses, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
                datasets: [{
                    label: 'Reservas',
                    data: [<?php 
                        $dados = array_fill(0, 12, 0);
                        foreach ($reservas_por_mes as $mes) {
                            $dados[$mes['mes'] - 1] = $mes['total'];
                        }
                        echo implode(',', $dados);
                    ?>],
                    borderColor: '#2E7D32',
                    backgroundColor: 'rgba(46, 125, 50, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
