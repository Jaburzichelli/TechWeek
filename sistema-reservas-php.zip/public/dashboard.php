<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

// Obter estatísticas
$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE status = "confirmada"');
$stmt->execute();
$reservas_confirmadas = $stmt->fetch()['total'];

$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE status = "pendente"');
$stmt->execute();
$reservas_pendentes = $stmt->fetch()['total'];

$stmt = $pdo->prepare('SELECT COUNT(*) as total FROM reservas WHERE usuario_id = ? AND status = "confirmada"');
$stmt->execute([$usuario['id']]);
$minhas_reservas = $stmt->fetch()['total'];

// Obter próximas reservas
$stmt = $pdo->prepare('
    SELECT r.*, l.nome as local_nome, u.nome as usuario_nome 
    FROM reservas r
    JOIN locais l ON r.local_id = l.id
    JOIN usuarios u ON r.usuario_id = u.id
    WHERE r.data_inicio > NOW() AND r.status = "confirmada"
    ORDER BY r.data_inicio ASC
    LIMIT 5
');
$stmt->execute();
$proximas_reservas = $stmt->fetchAll();

// Obter notificações
$notificacoes = obterNotificacoesNaoLidas($pdo, $usuario['id']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Reservas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container-fluid">
        <!-- Header -->
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?> (<?php echo ucfirst($usuario['perfil']); ?>)</span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <!-- Sidebar -->
        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item active">Dashboard</a>
                <a href="/reservas.php" class="nav-item">Minhas Reservas</a>
                <a href="/nova-reserva.php" class="nav-item">Nova Reserva</a>
                <a href="/calendario.php" class="nav-item">Calendário</a>
                
                <?php if ($usuario['perfil'] === 'admin'): ?>
                    <hr>
                    <h3>Administração</h3>
                    <a href="/admin/gerenciar-reservas.php" class="nav-item">Gerenciar Reservas</a>
                    <a href="/admin/usuarios.php" class="nav-item">Usuários</a>
                    <a href="/admin/locais.php" class="nav-item">Locais</a>
                    <a href="/admin/relatorios.php" class="nav-item">Relatórios</a>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="dashboard-header">
                <h2>Bem-vindo, <?php echo $usuario['nome']; ?>!</h2>
                <p>Aqui está um resumo do seu sistema de reservas</p>
            </div>

            <!-- Cards de Estatísticas -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📅</div>
                    <div class="stat-content">
                        <h3>Reservas Confirmadas</h3>
                        <p class="stat-number"><?php echo $reservas_confirmadas; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-content">
                        <h3>Pendentes de Aprovação</h3>
                        <p class="stat-number"><?php echo $reservas_pendentes; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✓</div>
                    <div class="stat-content">
                        <h3>Minhas Reservas</h3>
                        <p class="stat-number"><?php echo $minhas_reservas; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">🔔</div>
                    <div class="stat-content">
                        <h3>Notificações</h3>
                        <p class="stat-number"><?php echo count($notificacoes); ?></p>
                    </div>
                </div>
            </div>

            <!-- Próximas Reservas -->
            <div class="section">
                <h3>Próximas Reservas Confirmadas</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Título</th>
                                <th>Local</th>
                                <th>Data/Hora</th>
                                <th>Solicitante</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($proximas_reservas as $reserva): ?>
                                <tr>
                                    <td><?php echo $reserva['titulo']; ?></td>
                                    <td><?php echo $reserva['local_nome']; ?></td>
                                    <td><?php echo formatarData($reserva['data_inicio']); ?></td>
                                    <td><?php echo $reserva['usuario_nome']; ?></td>
                                    <td><span class="badge badge-success"><?php echo ucfirst($reserva['status']); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Gráfico de Reservas por Mês -->
            <div class="section">
                <h3>Reservas por Mês</h3>
                <canvas id="chartReservas"></canvas>
            </div>
        </main>
    </div>

    <script>
        // Gráfico de Reservas
        const ctx = document.getElementById('chartReservas').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
                datasets: [{
                    label: 'Reservas Confirmadas',
                    data: [12, 19, 3, 5, 2, 3, 7, 8, 5, 4, 6, 9],
                    backgroundColor: '#2E7D32',
                    borderColor: '#1B5E20',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
