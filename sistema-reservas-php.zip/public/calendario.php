<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

// Obter reservas confirmadas
$stmt = $pdo->prepare('
    SELECT r.*, l.nome as local_nome 
    FROM reservas r
    JOIN locais l ON r.local_id = l.id
    WHERE r.status = "confirmada"
    ORDER BY r.data_inicio
');
$stmt->execute();
$reservas = $stmt->fetchAll();

// Converter para formato JSON para o calendário
$eventos = [];
foreach ($reservas as $reserva) {
    $eventos[] = [
        'title' => $reserva['titulo'] . ' - ' . $reserva['local_nome'],
        'start' => $reserva['data_inicio'],
        'end' => $reserva['data_fim'],
        'id' => $reserva['id']
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário - Sistema de Reservas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css' rel='stylesheet' />
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js'></script>
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?></span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <a href="/reservas.php" class="nav-item">Minhas Reservas</a>
                <a href="/nova-reserva.php" class="nav-item">Nova Reserva</a>
                <a href="/calendario.php" class="nav-item active">Calendário</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Calendário de Reservas</h2>
            </div>

            <div class="section">
                <div id="calendar"></div>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const calendarEl = document.getElementById('calendar');
            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'pt-br',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: <?php echo json_encode($eventos); ?>,
                eventClick: function(info) {
                    alert('Reserva: ' + info.event.title);
                }
            });
            calendar.render();
        });
    </script>

    <style>
        #calendar {
            max-width: 100%;
        }

        .fc {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .fc .fc-button-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .fc .fc-button-primary:hover {
            background-color: var(--primary-dark);
        }

        .fc .fc-button-primary.fc-button-active {
            background-color: var(--primary-dark);
        }

        .fc .fc-daygrid-day.fc-day-today {
            background-color: rgba(46, 125, 50, 0.1);
        }

        .fc .fc-event {
            background-color: var(--primary);
            border-color: var(--primary-dark);
        }
    </style>
</body>
</html>
