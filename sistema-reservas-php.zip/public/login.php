<?php
require_once '../config/database.php';
require_once '../config/helpers.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizar($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    if (empty($email) || empty($senha)) {
        $erro = 'Email e senha são obrigatórios';
    } elseif (!validarEmail($email)) {
        $erro = 'Email inválido';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ? AND ativo = TRUE');
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();
        
        if ($usuario && verificarSenha($senha, $usuario['senha'])) {
            session_start();
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['perfil'] = $usuario['perfil'];
            
            registrarLog($pdo, $usuario['id'], 'LOGIN', 'Usuário fez login');
            
            header('Location: /dashboard.php');
            exit;
        } else {
            $erro = 'Email ou senha incorretos';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Reservas SENAC</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1>Sistema de Reservas</h1>
                <p>SENAC</p>
            </div>
            
            <?php if ($erro): ?>
                <div class="alert alert-danger"><?php echo $erro; ?></div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Entrar</button>
            </form>
            
            <div class="login-footer">
                <p>Credenciais de teste:</p>
                <p><strong>Admin:</strong> admin@senac.com / senha123</p>
                <p><strong>Colaborador:</strong> joao@senac.com / senha123</p>
            </div>
        </div>
    </div>
</body>
</html>
