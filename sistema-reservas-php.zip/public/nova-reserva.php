<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

$erro = '';
$sucesso = '';

// Obter locais disponíveis
$stmt = $pdo->prepare('SELECT * FROM locais WHERE ativo = TRUE ORDER BY nome');
$stmt->execute();
$locais = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $local_id = (int)($_POST['local_id'] ?? 0);
    $titulo = sanitizar($_POST['titulo'] ?? '');
    $descricao = sanitizar($_POST['descricao'] ?? '');
    $data_inicio = $_POST['data_inicio'] ?? '';
    $data_fim = $_POST['data_fim'] ?? '';
    $tipo = sanitizar($_POST['tipo'] ?? 'interna');
    
    if (empty($titulo) || empty($local_id) || empty($data_inicio) || empty($data_fim)) {
        $erro = 'Todos os campos obrigatórios devem ser preenchidos';
    } elseif (strtotime($data_inicio) >= strtotime($data_fim)) {
        $erro = 'A data de fim deve ser posterior à data de início';
    } elseif (verificarConflito($pdo, $local_id, $data_inicio, $data_fim)) {
        $erro = 'Já existe uma reserva neste horário para este local';
    } else {
        $stmt = $pdo->prepare('
            INSERT INTO reservas (usuario_id, local_id, titulo, descricao, data_inicio, data_fim, tipo, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ');
        
        $status = ($usuario['perfil'] === 'admin') ? 'confirmada' : 'pendente';
        
        if ($stmt->execute([$usuario['id'], $local_id, $titulo, $descricao, $data_inicio, $data_fim, $tipo, $status])) {
            $reserva_id = $pdo->lastInsertId();
            registrarLog($pdo, $usuario['id'], 'CRIAR_RESERVA', "Reserva #$reserva_id criada");
            
            if ($usuario['perfil'] !== 'admin') {
                criarNotificacao($pdo, 1, $reserva_id, 'nova_reserva', "Nova reserva de {$usuario['nome']}: $titulo");
            }
            
            $sucesso = 'Reserva criada com sucesso!';
            header('Refresh: 2; url=/reservas.php');
        } else {
            $erro = 'Erro ao criar reserva';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Reserva - Sistema de Reservas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?></span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <a href="/reservas.php" class="nav-item">Minhas Reservas</a>
                <a href="/nova-reserva.php" class="nav-item active">Nova Reserva</a>
                <a href="/calendario.php" class="nav-item">Calendário</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Nova Reserva</h2>
                <p>Preencha o formulário abaixo para criar uma nova reserva</p>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-danger"><?php echo $erro; ?></div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
                <div class="alert alert-success"><?php echo $sucesso; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" class="form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="titulo">Título da Reserva *</label>
                            <input type="text" id="titulo" name="titulo" required>
                        </div>

                        <div class="form-group">
                            <label for="local_id">Local *</label>
                            <select id="local_id" name="local_id" required>
                                <option value="">Selecione um local</option>
                                <?php foreach ($locais as $local): ?>
                                    <option value="<?php echo $local['id']; ?>">
                                        <?php echo $local['nome']; ?> (Cap: <?php echo $local['capacidade']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="data_inicio">Data/Hora de Início *</label>
                            <input type="datetime-local" id="data_inicio" name="data_inicio" required>
                        </div>

                        <div class="form-group">
                            <label for="data_fim">Data/Hora de Fim *</label>
                            <input type="datetime-local" id="data_fim" name="data_fim" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" rows="4"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="tipo">Tipo de Reserva *</label>
                        <select id="tipo" name="tipo" required>
                            <option value="interna">Interna (Colaborador)</option>
                            <option value="externa">Externa (Empresa)</option>
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Criar Reserva</button>
                        <a href="/reservas.php" class="btn btn-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
