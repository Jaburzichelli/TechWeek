<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

$reserva_id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM reservas WHERE id = ? AND usuario_id = ?');
$stmt->execute([$reserva_id, $usuario['id']]);
$reserva = $stmt->fetch();

if ($reserva && $reserva['status'] === 'pendente') {
    $stmt = $pdo->prepare('UPDATE reservas SET status = "cancelada" WHERE id = ?');
    $stmt->execute([$reserva_id]);
    registrarLog($pdo, $usuario['id'], 'CANCELAR_RESERVA', "Reserva #$reserva_id cancelada pelo usuário");
}

header('Location: /reservas.php');
exit;
?>
