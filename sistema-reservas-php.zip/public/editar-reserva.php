<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

$reserva_id = (int)($_GET['id'] ?? 0);
$erro = '';
$sucesso = '';

// Obter reserva
$stmt = $pdo->prepare('SELECT * FROM reservas WHERE id = ? AND usuario_id = ?');
$stmt->execute([$reserva_id, $usuario['id']]);
$reserva = $stmt->fetch();

if (!$reserva) {
    header('Location: /reservas.php');
    exit;
}

// Obter locais
$stmt = $pdo->prepare('SELECT * FROM locais WHERE ativo = TRUE ORDER BY nome');
$stmt->execute();
$locais = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = sanitizar($_POST['titulo'] ?? '');
    $local_id = (int)($_POST['local_id'] ?? 0);
    $descricao = sanitizar($_POST['descricao'] ?? '');
    $data_inicio = $_POST['data_inicio'] ?? '';
    $data_fim = $_POST['data_fim'] ?? '';
    
    if (empty($titulo) || empty($local_id) || empty($data_inicio) || empty($data_fim)) {
        $erro = 'Todos os campos obrigatórios devem ser preenchidos';
    } elseif (strtotime($data_inicio) >= strtotime($data_fim)) {
        $erro = 'A data de fim deve ser posterior à data de início';
    } elseif (verificarConflito($pdo, $local_id, $data_inicio, $data_fim, $reserva_id)) {
        $erro = 'Já existe uma reserva neste horário para este local';
    } else {
        $stmt = $pdo->prepare('
            UPDATE reservas 
            SET titulo = ?, local_id = ?, descricao = ?, data_inicio = ?, data_fim = ?
            WHERE id = ? AND usuario_id = ?
        ');
        
        if ($stmt->execute([$titulo, $local_id, $descricao, $data_inicio, $data_fim, $reserva_id, $usuario['id']])) {
            $sucesso = 'Reserva atualizada com sucesso!';
            registrarLog($pdo, $usuario['id'], 'EDITAR_RESERVA', "Reserva #$reserva_id editada");
            header('Refresh: 2; url=/reservas.php');
        } else {
            $erro = 'Erro ao atualizar reserva';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Reserva - Sistema de Reservas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?></span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <a href="/reservas.php" class="nav-item">Minhas Reservas</a>
                <a href="/nova-reserva.php" class="nav-item">Nova Reserva</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Editar Reserva #<?php echo $reserva_id; ?></h2>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-danger"><?php echo $erro; ?></div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
                <div class="alert alert-success"><?php echo $sucesso; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" class="form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="titulo">Título da Reserva</label>
                            <input type="text" id="titulo" name="titulo" value="<?php echo $reserva['titulo']; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="local_id">Local</label>
                            <select id="local_id" name="local_id" required>
                                <?php foreach ($locais as $local): ?>
                                    <option value="<?php echo $local['id']; ?>" <?php echo $local['id'] == $reserva['local_id'] ? 'selected' : ''; ?>>
                                        <?php echo $local['nome']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="data_inicio">Data/Hora de Início</label>
                            <input type="datetime-local" id="data_inicio" name="data_inicio" value="<?php echo formatarDataInput($reserva['data_inicio']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="data_fim">Data/Hora de Fim</label>
                            <input type="datetime-local" id="data_fim" name="data_fim" value="<?php echo formatarDataInput($reserva['data_fim']); ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" rows="4"><?php echo $reserva['descricao']; ?></textarea>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Atualizar Reserva</button>
                        <a href="/reservas.php" class="btn btn-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
