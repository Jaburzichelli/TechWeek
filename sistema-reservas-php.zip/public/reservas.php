<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/helpers.php';

verificarAutenticacao();
$usuario = obterUsuario($pdo);

$filtro_status = $_GET['status'] ?? '';

// Obter reservas do usuário
$query = 'SELECT r.*, l.nome as local_nome FROM reservas r 
          JOIN locais l ON r.local_id = l.id 
          WHERE r.usuario_id = ?';
$params = [$usuario['id']];

if ($filtro_status) {
    $query .= ' AND r.status = ?';
    $params[] = $filtro_status;
}

$query .= ' ORDER BY r.data_inicio DESC';

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$reservas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Reservas - Sistema de Reservas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="container-fluid">
        <header class="header">
            <div class="header-content">
                <h1>Sistema de Reservas SENAC</h1>
                <div class="user-menu">
                    <span><?php echo $usuario['nome']; ?></span>
                    <a href="/logout.php" class="btn btn-sm btn-danger">Sair</a>
                </div>
            </div>
        </header>

        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="/dashboard.php" class="nav-item">Dashboard</a>
                <a href="/reservas.php" class="nav-item active">Minhas Reservas</a>
                <a href="/nova-reserva.php" class="nav-item">Nova Reserva</a>
                <a href="/calendario.php" class="nav-item">Calendário</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h2>Minhas Reservas</h2>
                <a href="/nova-reserva.php" class="btn btn-primary">+ Nova Reserva</a>
            </div>

            <div class="filters">
                <a href="/reservas.php" class="filter-btn <?php echo !$filtro_status ? 'active' : ''; ?>">Todas</a>
                <a href="/reservas.php?status=pendente" class="filter-btn <?php echo $filtro_status === 'pendente' ? 'active' : ''; ?>">Pendentes</a>
                <a href="/reservas.php?status=confirmada" class="filter-btn <?php echo $filtro_status === 'confirmada' ? 'active' : ''; ?>">Confirmadas</a>
                <a href="/reservas.php?status=cancelada" class="filter-btn <?php echo $filtro_status === 'cancelada' ? 'active' : ''; ?>">Canceladas</a>
            </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Local</th>
                            <th>Data/Hora</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservas as $reserva): ?>
                            <tr>
                                <td><?php echo $reserva['titulo']; ?></td>
                                <td><?php echo $reserva['local_nome']; ?></td>
                                <td><?php echo formatarData($reserva['data_inicio']); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $reserva['status'] === 'confirmada' ? 'success' : 
                                             ($reserva['status'] === 'pendente' ? 'warning' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($reserva['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="/editar-reserva.php?id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-info">Editar</a>
                                    <?php if ($reserva['status'] === 'pendente'): ?>
                                        <a href="/cancelar-reserva.php?id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')">Cancelar</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
