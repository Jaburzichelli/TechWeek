<?php
// Configuração de Sessão

session_start();

// Função para verificar se usuário está autenticado
function verificarAutenticacao() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: /login.php');
        exit;
    }
}

// Função para verificar perfil
function verificarPerfil($perfis_permitidos) {
    if (!isset($_SESSION['perfil']) || !in_array($_SESSION['perfil'], $perfis_permitidos)) {
        header('Location: /acesso-negado.php');
        exit;
    }
}

// Função para fazer logout
function fazerLogout() {
    session_destroy();
    header('Location: /login.php');
    exit;
}

// Função para obter dados do usuário
function obterUsuario($pdo) {
    if (isset($_SESSION['usuario_id'])) {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = ?');
        $stmt->execute([$_SESSION['usuario_id']]);
        return $stmt->fetch();
    }
    return null;
}
?>
