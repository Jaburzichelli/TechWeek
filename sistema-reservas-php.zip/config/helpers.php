<?php
// Funções Auxiliares

// Sanitizar entrada
function sanitizar($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Gerar hash de senha
function gerarHashSenha($senha) {
    return password_hash($senha, PASSWORD_BCRYPT);
}

// Verificar senha
function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

// Formatar data
function formatarData($data) {
    return date('d/m/Y H:i', strtotime($data));
}

// Formatar data para input
function formatarDataInput($data) {
    return date('Y-m-d\TH:i', strtotime($data));
}

// Verificar conflito de horário
function verificarConflito($pdo, $local_id, $data_inicio, $data_fim, $reserva_id = null) {
    $query = 'SELECT COUNT(*) as total FROM reservas 
              WHERE local_id = ? 
              AND status IN ("confirmada", "pendente")
              AND ((data_inicio < ? AND data_fim > ?)
              OR (data_inicio < ? AND data_fim > ?)
              OR (data_inicio >= ? AND data_fim <= ?))';
    
    $params = [$local_id, $data_fim, $data_inicio, $data_fim, $data_inicio, $data_inicio, $data_fim];
    
    if ($reserva_id) {
        $query .= ' AND id != ?';
        $params[] = $reserva_id;
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $resultado = $stmt->fetch();
    
    return $resultado['total'] > 0;
}

// Registrar log
function registrarLog($pdo, $usuario_id, $acao, $descricao) {
    $stmt = $pdo->prepare('INSERT INTO logs (usuario_id, acao, descricao) VALUES (?, ?, ?)');
    $stmt->execute([$usuario_id, $acao, $descricao]);
}

// Criar notificação
function criarNotificacao($pdo, $usuario_id, $reserva_id, $tipo, $mensagem) {
    $stmt = $pdo->prepare('INSERT INTO notificacoes (usuario_id, reserva_id, tipo, mensagem) VALUES (?, ?, ?, ?)');
    $stmt->execute([$usuario_id, $reserva_id, $tipo, $mensagem]);
}

// Obter notificações não lidas
function obterNotificacoesNaoLidas($pdo, $usuario_id) {
    $stmt = $pdo->prepare('SELECT * FROM notificacoes WHERE usuario_id = ? AND lida = FALSE ORDER BY criado_em DESC LIMIT 10');
    $stmt->execute([$usuario_id]);
    return $stmt->fetchAll();
}
?>
