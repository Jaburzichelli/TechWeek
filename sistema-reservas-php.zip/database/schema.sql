-- Banco de Dados para Sistema de Reservas SENAC
CREATE DATABASE IF NOT EXISTS sistema_reservas;
USE sistema_reservas;

-- Tabela de Usuários
CREATE TABLE usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  senha VARCHAR(255) NOT NULL,
  perfil ENUM('admin', 'colaborador', 'visualizador') DEFAULT 'colaborador',
  departamento VARCHAR(100),
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Locais/Espaços
CREATE TABLE locais (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(255) NOT NULL,
  descricao TEXT,
  capacidade INT,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Reservas
CREATE TABLE reservas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  local_id INT NOT NULL,
  titulo VARCHAR(255) NOT NULL,
  descricao TEXT,
  data_inicio DATETIME NOT NULL,
  data_fim DATETIME NOT NULL,
  status ENUM('pendente', 'confirmada', 'cancelada', 'rejeitada') DEFAULT 'pendente',
  tipo ENUM('interna', 'externa') DEFAULT 'interna',
  observacoes TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (local_id) REFERENCES locais(id),
  INDEX idx_data (data_inicio, data_fim),
  INDEX idx_status (status),
  INDEX idx_local (local_id)
);

-- Tabela de Notificações
CREATE TABLE notificacoes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  reserva_id INT,
  tipo VARCHAR(50),
  mensagem TEXT,
  lida BOOLEAN DEFAULT FALSE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (reserva_id) REFERENCES reservas(id)
);

-- Tabela de Logs
CREATE TABLE logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  usuario_id INT,
  acao VARCHAR(255),
  descricao TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Inserir dados iniciais
INSERT INTO usuarios (nome, email, senha, perfil, departamento) VALUES
('Vinícius Admin', 'admin@senac.com', '$2y$10$YourHashedPasswordHere', 'admin', 'Administração'),
('Professor João', 'joao@senac.com', '$2y$10$YourHashedPasswordHere', 'colaborador', 'Educação'),
('Professora Maria', 'maria@senac.com', '$2y$10$YourHashedPasswordHere', 'colaborador', 'Educação'),
('Visualizador', 'visualizador@senac.com', '$2y$10$YourHashedPasswordHere', 'visualizador', 'Geral');

INSERT INTO locais (nome, descricao, capacidade) VALUES
('Auditório Principal', 'Auditório com capacidade para 200 pessoas', 200),
('Sala de Treinamento A', 'Sala com equipamentos de informática', 30),
('Sala de Treinamento B', 'Sala com projetor e quadro branco', 25),
('Laboratório', 'Laboratório com equipamentos especializados', 20),
('Sala de Reuniões', 'Sala para reuniões executivas', 15);
